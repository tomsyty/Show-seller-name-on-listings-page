window.addEventListener('load', () => {
	console.log('Załadowano skrypt showSellerNameOnListingsPage');
	const toast = document.createElement('div');
  toast.id = 'aeToast';
  toast.classList.add('aeToastHidden');
  document.body.appendChild(toast);
	main();
});

async function readDataFromLocalStorage(data) {
	return new Promise((resolve, reject) => {
		chrome.storage.local.get(data, (result) => {
			chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(result);
		});
	});
}

async function main() {
	let readedValue;
	let blockedSellers;
  try {
    readedValue = await readDataFromLocalStorage(['sellerNames']);
  } catch (error) {
    toastMessage(`Błąd! Nie udało się wczytać listy użytkowników. ${error instanceof Error ? error.message : error}`);
    return Promise.reject(false);
  }
	blockedSellers = readedValue.sellerNames;

	const urlObserver = new MutationObserver(mutations => {
		mutations.forEach(mutation => {
			if (mutation.type === 'attributes' && mutation.attributeName === 'href') {
				processPage(blockedSellers);
			}
		});
	});
	urlObserver.observe(document, {	subtree: true, childList: true, attributes: true, attributeFilter: ['href'] });
	processPage(blockedSellers)
}

async function processPage(blockedSellers) {
	let itemsContainer;
	itemsContainer = document.querySelector('div[data-box-name="items container"]');
	if (itemsContainer === null) {
		const delay = t => new Promise(resolve => setTimeout(resolve, t));
		await delay(500);
		return await processPage(blockedSellers);
	}
	
	const items = itemsContainer.querySelectorAll('article');
	const evEnter = new Event('mouseenter');

	const articleObserver = new IntersectionObserver(entries => {
		entries.forEach(entry => {
			if (entry.intersectionRatio > 0) {
				const baseDiv = entry.target?.firstElementChild?.firstElementChild?.firstElementChild;
				if (baseDiv && baseDiv.nodeName === 'DIV') {
					const baseDivObserver = new MutationObserver(mutations => {
						mutations.forEach(mutation => {
							mutation.addedNodes.forEach(async(node) => {
								const article = node.parentElement?.parentElement?.parentElement?.parentElement;
								const delay = t => new Promise(resolve => setTimeout(resolve, t));
								await delay(100);
								if (article) {
									const sellerText = article.querySelector('a[href^="https://allegro.pl/uzytkownik/"]');
									if (sellerText) {
										sellerTextReplaced = sellerText.textContent.replace(' - ', '\n');
										const sellerName = sellerTextReplaced.split('\n')[0];
										const outputSpan = article.querySelector('span[class="mgmw_3z mpof_z0 mgn2_12"]');
										if (outputSpan?.dataset?.username === undefined) {
											outputSpan.innerText = sellerTextReplaced;
											if (blockedSellers.includes(sellerName)) {
												outputSpan.classList.add('blacklist');
												article.firstElementChild.classList.add('blacklist');
											}
											outputSpan.dataset.username = true;
										}
									}
								}
							});
						});
					});	
					baseDivObserver.observe(baseDiv, { subtree: true, childList: true });

					baseDiv.addEventListener('mouseenter', baseDivEnter, { once: true });
					baseDiv.dispatchEvent(evEnter);	 
				}
			}
		});
	}, {
		root: null,
		threshold: 0,
		rootMargin: '200px'
	});

	const articleMutationObserver = new MutationObserver(mutations => {
		for (const mutation of mutations) {
			if (mutation.target.nodeName === 'ARTICLE' && mutation.addedNodes.length === 1) {
				const baseDiv = mutation.target?.firstElementChild?.firstElementChild?.firstElementChild;
				if (baseDiv && baseDiv.nodeName === 'DIV') {
					const baseDivObserver = new MutationObserver(mutations => {
						mutations.forEach(mutation => {
							mutation.addedNodes.forEach(async(node) => {
								const article = node.parentElement?.parentElement?.parentElement?.parentElement;
								const delay = t => new Promise(resolve => setTimeout(resolve, t));
								await delay(100);
								if (article) {
									const sellerText = article.querySelector('a[href^="https://allegro.pl/uzytkownik/"]');
									if (sellerText) {
										sellerTextReplaced = sellerText.textContent.replace(' - ', '\n');
										const sellerName = sellerTextReplaced.split('\n')[0];
										const outputSpan = article.querySelector('span[class="mgmw_3z mpof_z0 mgn2_12"]');
										if (outputSpan?.dataset?.username === undefined) {
											outputSpan.innerText = sellerTextReplaced;
											if (blockedSellers.includes(sellerName)) {
												outputSpan.classList.add('blacklist');
												article.firstElementChild.classList.add('blacklist');
											}
											outputSpan.dataset.username = true;
										}
									}
								}
							});
						});
					});	
					baseDivObserver.observe(baseDiv, { subtree: true, childList: true });

					baseDiv.addEventListener('mouseenter', baseDivEnter, { once: true });
					baseDiv.dispatchEvent(evEnter);	 
				}
			}
		}
	});
	
	items.forEach(item => {
		articleObserver.observe(item);
		articleMutationObserver.observe(item, { childList: true, subtree: true });
	});

	async function baseDivEnter(e) {
		const evLeave = new Event('mouseleave');
		e.target.dispatchEvent(evLeave);
	}
}