async function saveDataToLocalStorage(data) {
	return new Promise((resolve, reject) => {
		chrome.storage.local.set(data, () => {
			chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(true);
		});
	});
}

async function readDataFromLocalStorage(data) {
	return new Promise((resolve, reject) => {
		chrome.storage.local.get(data, (result) => {
			chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(result);
		});
	});
}

document.addEventListener('DOMContentLoaded', async () => {
  const sellerNameTextArea = document.getElementById('sellerNameTextArea');
  let readedValue;
  try {
    readedValue = await readDataFromLocalStorage(['sellerNames']);
  } catch (error) {
    toastMessage(`Błąd! Nie udało się wczytać listy użytkowników. ${error instanceof Error ? error.message : error}`);
    return Promise.reject(false);
  }

  if (readedValue.sellerNames !== undefined) {
    sellerNameTextArea.value = readedValue.sellerNames.join('\n');
  }
  
  const saveButton = document.getElementById('saveButton');
  saveButton.addEventListener('click', async (e) => {
    try {
      const uniqueSellerNames = [...new Set(sellerNameTextArea.value.split('\n'))];
      sellerNameTextArea.value = uniqueSellerNames.join('\n');
			await saveDataToLocalStorage({ sellerNames: uniqueSellerNames });
		} catch (error) {
			toastMessage(`Błąd! Nie udało się zapisać listy użytkowników. ${error instanceof Error ? error.message : error}`);
			return Promise.reject(false);
		}
    toastMessage('Zapisano');
  });
});