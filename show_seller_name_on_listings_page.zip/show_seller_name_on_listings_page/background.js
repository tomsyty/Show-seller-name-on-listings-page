const UPDATE_CHECK_FAILED_MESSAGE = 'Nie udało się sprawdzić aktualizacji rozszerzenia.';
const UPDATE_CHECK_STATUS_CODE_NOT_200 = 'Brak pliku z informacją o aktualizacji.';

chrome.runtime.onInstalled.addListener(details => {
	if (details.reason === 'install') {
		chrome.storage.local.set({
			sellerNames: ['']
		});
	}
});

(function main() {
  console.log('Załadowano rozszerzenie showSellerNameOnListingsPage');
})();

fetch('https:/raw.githubusercontent.com/tomsyty/Show-seller-name-on-listings-page/main/current-version').then(response => {
	if (response.status !== 200) throw new Error(UPDATE_CHECK_STATUS_CODE_NOT_200);
	return response.text();
}).then(currentVersion => {
	if (currentVersion.trim() !== chrome.runtime.getManifest().version) {
		chrome.permissions.contains({ permissions: ['notifications'] }).then(granted => {
			if (granted) {
				chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
					if (buttonIndex === 0) {
						chrome.tabs.create({url: 'https://github.com/tomsyty/Show-sellername-on-auctions-listing'});
					}
				});
				chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Aktualizacja rozszerzenia', message: `Znaleziono nową wersję rozszerzenia "${chrome.runtime.getManifest().name}". Pobierz ją i zainstaluj ręcznie.`, buttons: [{ title: 'Otwórz stronę rozszerzenia' }], silent: true });
			} else {
				console.log('brak uprawnień do powiadomień');
			}
		});
	}
}).catch(error => console.log(`${UPDATE_CHECK_FAILED_MESSAGE} ${error.message}`));